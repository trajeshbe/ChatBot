# Procurement-matching - Supply-chain Vertical

**Tier**: 2 (Domain Vertical) | **Vertical**: supply-chain
**Source**: prototypes/procurement-matcher.md, prototypes/vendor-recommendation.md, prototypes/tender-intelligence.md

## Overview
Domain-specific capability for supply-chain: procurement-matching

## Source Material
See: `.claude/skills/prototypes/procurement-matcher.md, prototypes/vendor-recommendation.md, prototypes/tender-intelligence.md`

## Implementation
Uses domain-specific prompts and schemas from: `prompt_engineering/prompt/supply-chain_prompts.yaml`

## Related
See other skills in [supply-chain vertical](./)
